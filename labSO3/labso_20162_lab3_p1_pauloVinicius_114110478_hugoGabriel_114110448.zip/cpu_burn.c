#include <math.h>
#include <stdio.h>
int main() {
long int tempo = 500000000;
	while(tempo-- > 0) {
		pow(1.2, 2.3);
	}
	return 0;
}
